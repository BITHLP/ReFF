View the archived First TextWorld Problems competition at [LINK](https://competitions.codalab.org/competitions/21557#learn_the_details-data) to download Agent dataset.

Alternatively, directly download the dataset from [LINK](https://aka.ms/ftwp/dataset.zip)