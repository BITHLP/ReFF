import os
import zipfile
from urllib.request import urlretrieve

def get_Agent():
    print('Downloading Agent Task...')
    url = 'https://aka.ms/ftwp/dataset.zip'
    save_dir = './ftwp'
    os.makedirs(save_dir, exist_ok=True)
    filename, _ = urlretrieve(url)
    with zipfile.ZipFile(filename, 'r') as zip_ref:
        zip_ref.extractall(save_dir)
    os.remove(filename)

if __name__ == '__main__':
    get_Agent()